package xyz.lawlietcache;

import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Random;

public class Rule34Listener extends ListenerAdapter {
    private final OkHttpClient client = new OkHttpClient();
    private final String API_KEY = "de27807b669f210b834cfa99a8b2846bf2805a1d07d29d0c708a008c4b0d998e64350ad922a3448207c04e592a8e352f4d60c211cfa396cebc387373eae3518a";
    private final String USER_ID = "5346603";

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (event.getAuthor().isBot()) {
            return;
        }

        String message = event.getMessage().getContentRaw();
        if (message.startsWith("!a34 ")) {
            String tags = message.substring("!a34 ".length()).trim();
            event.getChannel().sendMessage("Searching for images with tags: " + tags).queue();

            try {
                // Construct the API URL with tags and credentials
                HttpUrl.Builder urlBuilder = HttpUrl.parse("https://api.rule34.xxx/index.php").newBuilder();
                urlBuilder.addQueryParameter("page", "dapi");
                urlBuilder.addQueryParameter("s", "post");
                urlBuilder.addQueryParameter("q", "index");
                urlBuilder.addQueryParameter("json", "1");
                urlBuilder.addQueryParameter("tags", tags);
                urlBuilder.addQueryParameter("limit", "100");
                urlBuilder.addQueryParameter("api_key", API_KEY);
                urlBuilder.addQueryParameter("user_id", USER_ID);

                String url = urlBuilder.build().toString();
                Request request = new Request.Builder().url(url).build();

                // Execute the request
                Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected response code " + response);
                }

                // Parse the JSON response
                String responseBody = response.body().string();
                JSONArray posts = new JSONArray(responseBody);

                if (posts.isEmpty()) {
                    event.getChannel().sendMessage("Sorry, no images found for those tags.").queue();
                    return;
                }

                // Select a random image from the results
                int randomIndex = new Random().nextInt(posts.length());
                JSONObject randomPost = posts.getJSONObject(randomIndex);
                String imageUrl = randomPost.getString("file_url");

                // Send the image URL to the channel
                event.getChannel().sendMessage(imageUrl).queue();

            } catch (IOException | org.json.JSONException e) {
                event.getChannel().sendMessage("An error occurred while searching for images.").queue();
                e.printStackTrace();
            }
        }
    }
}