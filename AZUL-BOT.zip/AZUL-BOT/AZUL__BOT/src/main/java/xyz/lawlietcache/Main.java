package xyz.lawlietcache;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.requests.GatewayIntent;
import javax.security.auth.login.LoginException;

public class Main {
    public static void main(String[] args) throws LoginException {
        // This is a placeholder for your bot's token.
        // It is highly recommended to read this from an external file
        // or environment variable for security reasons.
        String token = "MTQxNTgzNzYwMjI1ODQ4OTQ2NA.GTWdWp.GxNweGLjqpd3UV8XAtjkwvNkEqqho6pEzACQE8";

        JDA jda = JDABuilder.createDefault(token)
                .enableIntents(GatewayIntent.MESSAGE_CONTENT)
                .addEventListeners(new Rule34Listener())
                .build();
    }
}